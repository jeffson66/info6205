
public class BinaryTree<T> {
    public Node<T> root;
    public BinaryTree(){

    }
    public void setRoot(Node<T> root){
        this.root = root;
    }

}
