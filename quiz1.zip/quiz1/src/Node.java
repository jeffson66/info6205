public class Node<T> {
    Node<T> left;
    Node<T> right;
    T val;
    public Node(T val){
        this.val = val;
    }

}
